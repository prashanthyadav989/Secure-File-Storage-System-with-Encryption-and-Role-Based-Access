# Secure File Storage System (Demo)

Minimal Flask demo implementing:
- Encrypted file storage (Fernet AES)
- Role-Based Access Control (Admin / Manager / User)
- Simple auth with hashed passwords
- Audit logging

## Quick start (local demo)
1. Create a virtualenv and activate it.
2. `pip install -r requirements.txt`
3. Run: `python app.py`
4. Open http://127.0.0.1:5000

Default admin created on first run:
- username: admin
- password: admin123

NOTE: This is a demo skeleton. For production, use HTTPS, secure key management, stronger auth, and validate inputs.
