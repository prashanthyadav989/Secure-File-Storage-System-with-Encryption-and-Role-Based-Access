import os
from cryptography.fernet import Fernet

KEYFILE = 'key.key'

def ensure_key():
    if not os.path.exists(KEYFILE):
        key = Fernet.generate_key()
        with open(KEYFILE, 'wb') as fh:
            fh.write(key)

def load_key():
    with open(KEYFILE, 'rb') as fh:
        return fh.read()

def encrypt_bytes(data: bytes) -> bytes:
    key = load_key()
    f = Fernet(key)
    return f.encrypt(data)

def decrypt_bytes(token: bytes) -> bytes:
    key = load_key()
    f = Fernet(key)
    return f.decrypt(token)
