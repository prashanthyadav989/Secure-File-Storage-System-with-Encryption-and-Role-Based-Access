import os
from flask import Flask, render_template, request, redirect, url_for, flash, send_file, abort
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import LoginManager, login_user, login_required, logout_user, current_user, UserMixin
from models import init_db, Session, User, File
from crypto import ensure_key, encrypt_bytes, decrypt_bytes
from io import BytesIO

UPLOAD_FOLDER = os.path.join(os.getcwd(), 'uploads')
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

app = Flask(__name__)
app.config['SECRET_KEY'] = 'dev-secret-key'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

login_manager = LoginManager()
login_manager.login_view = 'login'
login_manager.init_app(app)

@login_manager.user_loader
def load_user(user_id):
    session = Session()
    return session.get(User, int(user_id))

@app.before_first_request
def setup():
    init_db()
    ensure_key()
    # create default admin if none exist
    session = Session()
    if session.query(User).count() == 0:
        admin = User(username='admin', password_hash=generate_password_hash('admin123'), role='Admin')
        session.add(admin)
        session.commit()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET','POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        role = request.form.get('role','User')
        session = Session()
        if session.query(User).filter_by(username=username).first():
            flash('Username exists')
            return redirect(url_for('register'))
        u = User(username=username, password_hash=generate_password_hash(password), role=role)
        session.add(u); session.commit()
        flash('Registered. Please login.')
        return redirect(url_for('login'))
    return render_template('register.html')

@app.route('/login', methods=['GET','POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        session = Session()
        user = session.query(User).filter_by(username=username).first()
        if user and check_password_hash(user.password_hash, password):
            login_user(user)
            return redirect(url_for('dashboard'))
        flash('Invalid credentials')
    return render_template('login.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

@app.route('/dashboard')
@login_required
def dashboard():
    session = Session()
    files = session.query(File).all()
    return render_template('dashboard.html', files=files)

def allowed_upload(role, file_record=None):
    # Simple RBAC: Admin can do anything; Manager can access Manager/User files; User only own/upload
    if current_user.role == 'Admin':
        return True
    if current_user.role == 'Manager':
        return True
    if current_user.role == 'User':
        # allow if uploading or owner matches
        return True
    return False

@app.route('/upload', methods=['GET','POST'])
@login_required
def upload():
    if request.method == 'POST':
        f = request.files.get('file')
        if not f:
            flash('No file')
            return redirect(url_for('upload'))
        filename = secure_filename(f.filename)
        data = f.read()
        enc = encrypt_bytes(data)
        # save encrypted file to disk
        path = os.path.join(app.config['UPLOAD_FOLDER'], filename + '.enc')
        with open(path, 'wb') as fh:
            fh.write(enc)
        # create DB record
        session = Session()
        file_rec = File(filename=filename, path=path, owner_id=current_user.id, allowed_role='Manager')
        session.add(file_rec); session.commit()
        flash('Uploaded and encrypted')
        return redirect(url_for('dashboard'))
    return render_template('upload.html')

@app.route('/download/<int:file_id>')
@login_required
def download(file_id):
    session = Session()
    file_rec = session.get(File, file_id)
    if not file_rec:
        abort(404)
    # RBAC check: Admin or Manager or owner
    if current_user.role != 'Admin' and current_user.role != 'Manager' and file_rec.owner_id != current_user.id:
        abort(403)
    with open(file_rec.path, 'rb') as fh:
        enc = fh.read()
    data = decrypt_bytes(enc)
    return send_file(BytesIO(data), download_name=file_rec.filename, as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
