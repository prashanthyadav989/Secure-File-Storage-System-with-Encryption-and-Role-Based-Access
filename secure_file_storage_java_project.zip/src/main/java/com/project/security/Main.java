
package com.project.security;

public class Main {
    public static void main(String[] args) {
        System.out.println("Secure File Storage System Started...");
    }
}
