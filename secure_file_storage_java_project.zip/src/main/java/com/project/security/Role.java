
package com.project.security;

public enum Role {
    ADMIN,
    USER,
    VIEWER
}
